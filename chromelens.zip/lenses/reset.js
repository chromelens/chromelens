var elem = document.getElementById("colorFilters");
if (elem) {
  elem.parentElement.removeChild(elem);
}
