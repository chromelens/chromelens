console.log('content script loaded')
document.body.style.backgroundColor="blue";
