document.body.style.filter = "";
document.body.style.webkitFilter = "";
