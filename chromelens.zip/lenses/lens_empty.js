console.log('content script loaded')

document.body.style.filter = "";
document.body.style.webkitFilter = "";