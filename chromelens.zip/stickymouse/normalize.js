console.log('normalize')
