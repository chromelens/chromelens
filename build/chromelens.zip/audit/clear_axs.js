var base = document.getElementById("chrome-lens-base")
if (base) { base.remove(); }
