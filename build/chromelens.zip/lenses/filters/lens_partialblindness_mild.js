document.body.style.filter = "blur(1px)";
document.body.style.webkitFilter = "blur(1px)";
